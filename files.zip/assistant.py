"""LegalAid-GPT demo backend: guardrails, retrieval, answer generation, ask().

Fully local: no external API. Retrieval is simple BM25 (pure Python) so the demo
runs anywhere. In the real system P6 replaces retrieve() with embeddings plus a
vector index, and P7/P8 replace the guardrails and generate() with the final ones.
The Streamlit app only ever calls ask().
"""
import json
import math
import os
import re
import time
import urllib.request
from collections import Counter
from pathlib import Path

HERE = Path(__file__).parent
CHUNKS_PATHS = [Path("data/chunks.jsonl"), HERE / "data" / "chunks.jsonl", HERE / "demo_chunks.jsonl"]
DISCLAIMER = "This is general legal information, not legal advice. For serious matters, speak to a qualified lawyer or a legal aid office."

# Optional local LLM through Ollama (runs on this machine, http://localhost). If it
# is not running, the demo falls back to a template answer built from the passages.
OLLAMA_URL = os.environ.get("OLLAMA_URL", "http://localhost:11434/api/generate")
OLLAMA_MODEL = os.environ.get("OLLAMA_MODEL", "llama3.2:3b")

TOP_K = 3
MIN_SCORE = 1.0          # tune this on real questions (P6/P9)
MIN_MATCHED_TERMS = 2


# ------------------------------------------------------------- data loading
def load_chunks():
    for p in CHUNKS_PATHS:
        if p.exists():
            with open(p, encoding="utf-8") as f:
                chunks = [json.loads(line) for line in f if line.strip()]
            return chunks, p.name == "demo_chunks.jsonl"
    return [], True


# --------------------------------------------------------------- retrieval
STOP = set("""a an the and or of to in on at for with by from is are was were be been am i me my we our you your he she it
they them their his her its this that these those what which who whom how when where why do does did can could should would
will shall may might must not no yes if then than so as about into over under up down out any some there here have has had
get got just also very please tell want need know happen happens happened""".split())


def stem(w):
    for suf in ("ing", "ed", "es", "s"):
        if w.endswith(suf) and len(w) - len(suf) >= 4:
            return w[: -len(suf)]
    return w


def tokenize(text):
    return [stem(t) for t in re.findall(r"[a-z0-9]+", text.lower()) if t not in STOP]


# Everyday words mapped to the wording used in the law. This is only a stand-in for the embedding
# model: with embeddings (P6) this map is not needed.
EXPAND = {
    "police": ["arrest", "detain"], "policeman": ["arrest", "detain"], "officer": ["arrest", "detain"],
    "judge": ["court"], "magistrate": ["court"], "jail": ["detain"], "prison": ["detain"], "cell": ["detain"],
    "custody": ["detain", "arrest"], "lawyer": ["legal", "practitioner"], "solicitor": ["legal", "practitioner"],
    "beat": ["torture", "dignity"], "beaten": ["torture", "dignity"], "slap": ["dignity"], "torture": ["dignity"],
    "trial": ["fair", "hearing"], "innocent": ["presumed", "innocent"], "sue": ["court", "redress"],
}


class Retriever:
    def __init__(self, chunks, k1=1.5, b=0.75):
        self.chunks, self.k1, self.b = chunks, k1, b
        self.docs = [tokenize(f"{c['heading']} {c['heading']} {c['text']} {' '.join(c.get('topics', []))}") for c in chunks]
        self.avg = sum(len(d) for d in self.docs) / max(len(self.docs), 1)
        df = Counter(t for d in self.docs for t in set(d))
        n = len(self.docs)
        self.idf = {t: math.log(1 + (n - c + 0.5) / (c + 0.5)) for t, c in df.items()}

    def retrieve(self, query, k=TOP_K):
        q = set(tokenize(query))
        for t in list(q):
            q.update(EXPAND.get(t, []))
        scored = []
        for chunk, doc in zip(self.chunks, self.docs):
            tf = Counter(doc)
            matched = [t for t in q if t in tf]
            score = sum(self.idf[t] * tf[t] * (self.k1 + 1) /
                        (tf[t] + self.k1 * (1 - self.b + self.b * len(doc) / self.avg)) for t in matched)
            need = min(MIN_MATCHED_TERMS, max(len(q), 1))
            if len(matched) >= need and score >= MIN_SCORE:
                scored.append((score, chunk))
        scored.sort(key=lambda x: -x[0])
        return [c for _, c in scored[:k]]


# -------------------------------------------------------------- guardrails
HARMFUL = [
    r"\bavoid (being )?(caught|arrest|the police|prosecution)", r"\bescape (the )?(police|arrest|justice|prison)",
    r"\b(hide|destroy|dispose of) (the )?(evidence|body|weapon)", r"\bget away with\b", r"\bevade (the )?(law|police|tax)",
    r"\bbribe\b", r"\bforge\b", r"\bhurt (him|her|them|someone)\b", r"\bhow (do|can) i (kill|poison|stab)\b",
]
INJECTION = [
    r"ignore (all |your |the )?(previous|above|prior) (instructions|rules)", r"disregard (your|the) (rules|instructions)",
    r"\b(reveal|show|print) (your )?(system )?prompt\b", r"\byou are now\b", r"\bpretend (you are|to be)\b", r"\bjailbreak\b",
]
PERSONAL_DATA = [r"\b\d{11}\b", r"\b(nin|bvn|passport number)\b"]
EMERGENCY = [r"\barrest(ed)?\b", r"\bdetain(ed)?\b", r"\bin (police )?(custody|cell)\b", r"\bbeat(en|ing)?\b",
             r"\bviolen(ce|t)\b", r"\bevict(ed|ion)\b", r"\bthreat(en|ened)\b"]
GUARANTEE = [r"\byou will (definitely )?win\b", r"\bguarantee(d)?\b", r"\bcertain(ly)? (win|succeed)\b"]


def matches(patterns, text):
    return any(re.search(p, text.lower()) for p in patterns)


def input_check(question):
    if matches(INJECTION, question):
        return "injection", ("I can't change my rules or share my instructions. I'm here to give general legal information from "
                              "the documents in my knowledge base. Is there a legal question I can help with?")
    if matches(HARMFUL, question):
        return "harmful", ("I can't help with avoiding the law or harming anyone. If you are in trouble with the law, the safest step "
                           "is to speak to a qualified lawyer or a legal aid office, and I can explain your rights if that would help.")
    if matches(PERSONAL_DATA, question):
        return "personal_data", ("Please don't type ID numbers or other sensitive personal details here. Remove them and ask your "
                                 "question again, and I'll explain the law in general terms.")
    return None, None


# --------------------------------------------------------------- answering
def emergency_block():
    return ("**If this is happening now:** if anyone is in immediate danger, contact emergency services (112). If someone has been "
            "arrested, ask which offence they're accused of, do not sign anything you don't understand, and contact a lawyer or the "
            "Legal Aid Council as soon as you can.\n\n")


def template_answer(question, chunks):
    lines = ["**What the law says (from the sources below):**"]
    for i, c in enumerate(chunks, 1):
        lines.append(f"- [{i}] **{c['section']}**, {c['doc_title']}: {c['text']}")
    lines.append("\n**What you can do next:** write down the date, place and names involved, keep any papers you're given, and ask "
                 "a lawyer or a legal aid office to look at your situation.")
    return "\n".join(lines)


def build_prompt(question, chunks):
    passages = "\n\n".join(f"[{i}] ({c['doc_title']}, {c['section']}) {c['text']}" for i, c in enumerate(chunks, 1))
    return ("You are a legal information assistant. Answer ONLY from the numbered passages. Cite every claim with its number like [1]. "
            "If the passages do not answer the question, say so. Use plain language. Do not promise any outcome.\n\n"
            f"Passages:\n{passages}\n\nQuestion: {question}\n\nAnswer:")


def generate(prompt, timeout=60):
    """One function for the local LLM, so it can be swapped. Returns None if no local model is running."""
    try:
        req = urllib.request.Request(OLLAMA_URL, data=json.dumps({"model": OLLAMA_MODEL, "prompt": prompt, "stream": False}).encode(),
                                     headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read())["response"].strip()
    except Exception:
        return None


def ask(question, history=None, use_llm=True, retriever=None):
    start = time.time()
    warnings = []
    retriever = retriever or Retriever(load_chunks()[0])

    kind, refusal = input_check(question)
    if kind:
        return {"answer": refusal, "citations": [], "grounded": False, "warnings": [f"blocked: {kind}"],
                "disclaimer": DISCLAIMER, "mode": "refusal", "seconds": round(time.time() - start, 2)}

    chunks = retriever.retrieve(question)
    if not chunks:
        return {"answer": "I couldn't find anything in my sources that covers this question, so I won't guess. "
                          "A lawyer, a legal aid office or the relevant government agency is the best place to ask.",
                "citations": [], "grounded": False, "warnings": ["no relevant source found"], "disclaimer": DISCLAIMER,
                "mode": "not_covered", "seconds": round(time.time() - start, 2)}

    answer, mode = None, "template"
    if use_llm:
        answer = generate(build_prompt(question, chunks))
        if answer:
            cited = {int(n) for n in re.findall(r"\[(\d+)\]", answer)}
            if not cited or any(n < 1 or n > len(chunks) for n in cited):
                warnings.append("model answer failed the citation check; showing the template answer instead")
                answer = None
            elif matches(GUARANTEE, answer):
                warnings.append("model answer promised an outcome; showing the template answer instead")
                answer = None
            else:
                mode = "llm"
    if not answer:
        answer = template_answer(question, chunks)

    if matches(EMERGENCY, question):
        answer = emergency_block() + answer
        warnings.append("emergency guidance added")

    citations = [{"n": i, "chunk_id": c["chunk_id"], "doc_title": c["doc_title"], "section": c["section"],
                  "year": c.get("year"), "excerpt": c["text"]} for i, c in enumerate(chunks, 1)]
    return {"answer": answer, "citations": citations, "grounded": True, "warnings": warnings, "disclaimer": DISCLAIMER,
            "mode": mode, "seconds": round(time.time() - start, 2)}
