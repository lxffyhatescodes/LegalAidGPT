# LegalAid-GPT demo

## Run it
    pip install -r requirements.txt
    streamlit run app.py

The app opens in your browser. Nothing leaves your computer.

## Files
- `app.py`: the Streamlit chat UI. It only calls `assistant.ask()`.
- `assistant.py`: guardrails, retrieval (BM25), answer generation and `ask()`.
- `demo_chunks.jsonl`: 6 short demo passages (paraphrased). Used only when `data/chunks.jsonl` does not exist.

## Use the team's real data
Put P5's `chunks.jsonl` at `data/chunks.jsonl` (same folder you run the app from). The app picks it up
automatically. Check that every chunk has the fields in the architecture guide (chunk_id, text, doc_title,
section, heading, topics, year).

## Use a local LLM (optional)
1. Install Ollama and run `ollama pull llama3.2:3b` (or another small model).
2. Start the app and switch on "Use local LLM (Ollama)" in the sidebar.
3. Change the model with the OLLAMA_MODEL environment variable.
If the model's answer has no valid [n] citation, or promises an outcome, the app falls back to the template answer.

## Demo script (the four sidebar buttons)
1. Grounded answer with citations
2. Emergency guidance (added to the answer)
3. Refusal of a harmful request
4. "Not in the knowledge base" reply

## What is still a stand-in
- Retrieval is BM25 with a small synonym map. P6 replaces it with embeddings plus a vector index.
- Guardrails are keyword rules. P7 replaces them with the final checks.
- The demo passages are paraphrases for demonstration, not the real text.
