"""LegalAid-GPT demo (Streamlit UI). Run with:  streamlit run app.py

The UI only talks to assistant.ask(). It contains no retrieval or prompt logic.
"""
import json
import time
from pathlib import Path

import streamlit as st

import assistant

st.set_page_config(page_title="LegalAid-GPT demo", layout="centered")

DEMO_QUESTIONS = {
    "1. Grounded answer with citations": "What are my rights if I am arrested?",
    "2. Emergency guidance": "Police just arrested my brother, what do I do now?",
    "3. Refusal": "How do I avoid being caught by the police after a crime?",
    "4. Not in the knowledge base": "How do I register a company in Nigeria?",
}
LOG_FILE = Path("logs/interactions.jsonl")


@st.cache_resource
def get_retriever():
    """Load the chunks and build the index once, not on every question."""
    chunks, is_demo = assistant.load_chunks()
    return assistant.Retriever(chunks), is_demo, len(chunks)


def log_event(entry):
    LOG_FILE.parent.mkdir(exist_ok=True)
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(json.dumps(entry, ensure_ascii=False) + "\n")


def render_assistant(msg, idx):
    st.markdown(msg["content"])
    for w in msg.get("warnings", []):
        st.caption(f"Note: {w}")
    if msg.get("citations"):
        with st.expander(f"Sources ({len(msg['citations'])})"):
            for c in msg["citations"]:
                st.markdown(f"**[{c['n']}] {c['section']}**, {c['doc_title']} ({c.get('year')})")
                st.markdown(f"> {c['excerpt']}")
    st.caption(msg["disclaimer"])
    if hasattr(st, "feedback"):
        fb = st.feedback("thumbs", key=f"fb_{idx}")
        if fb is not None and st.session_state.get("log_on") and not msg.get("fb_logged"):
            log_event({"time": time.time(), "type": "feedback", "question": msg["question"], "thumbs_up": bool(fb)})
            msg["fb_logged"] = True


retriever, is_demo, n_chunks = get_retriever()

# ---------------------------------------------------------------- sidebar
with st.sidebar:
    st.header("Demo scenarios")
    for label, q in DEMO_QUESTIONS.items():
        if st.button(label, use_container_width=True):
            st.session_state["pending"] = q
    st.divider()
    use_llm = st.toggle("Use local LLM (Ollama)", value=False,
                        help="Needs Ollama running on this computer. Off = template answers built from the sources.")
    st.toggle("Log questions for evaluation", value=False, key="log_on",
              help="Saves to logs/interactions.jsonl on this computer only. Don't enter personal details.")
    if st.button("Clear conversation", use_container_width=True):
        st.session_state["messages"] = []
    st.caption(f"Knowledge base: {n_chunks} chunks")

# ------------------------------------------------------------------- main
st.title("LegalAid-GPT")
st.caption("Plain-language legal information from a fixed set of Nigerian legal documents. Runs on this computer.")
st.info(assistant.DISCLAIMER)
if is_demo:
    st.warning("Using the built-in demo data (6 short passages, paraphrased). Replace it with the team's real "
               "data/chunks.jsonl before presenting, and check every citation against the real text.")

if "messages" not in st.session_state:
    st.session_state["messages"] = []

for i, m in enumerate(st.session_state["messages"]):
    with st.chat_message(m["role"]):
        if m["role"] == "user":
            st.markdown(m["content"])
        else:
            render_assistant(m, i)

typed = st.chat_input("Ask a legal question, for example: What are my rights if I am arrested?")
question = st.session_state.pop("pending", None) or typed

if question:
    st.session_state["messages"].append({"role": "user", "content": question})
    with st.chat_message("user"):
        st.markdown(question)
    with st.chat_message("assistant"):
        with st.spinner("Searching the sources..."):
            a = assistant.ask(question, history=st.session_state["messages"], use_llm=use_llm, retriever=retriever)
        msg = {"role": "assistant", "content": a["answer"], "citations": a["citations"], "warnings": a["warnings"],
               "disclaimer": a["disclaimer"], "question": question}
        st.session_state["messages"].append(msg)
        render_assistant(msg, len(st.session_state["messages"]) - 1)
    if st.session_state.get("log_on"):
        log_event({"time": time.time(), "type": "answer", "question": question, "mode": a["mode"], "grounded": a["grounded"],
                   "chunks": [c["chunk_id"] for c in a["citations"]], "seconds": a["seconds"], "warnings": a["warnings"]})
