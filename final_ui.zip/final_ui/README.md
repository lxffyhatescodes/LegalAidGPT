# LegalAidGPT

A chat app that answers everyday legal questions in plain language and shows the sources behind each answer.
It is built with [Streamlit](https://streamlit.io). The app has three pages: **Home** (chat), **Explain a document** and **Analytics**.

## Run it

```
pip install -r requirements.txt
streamlit run ui/app.py
```

Run the command from this folder, not from inside `ui/`. The app opens at http://localhost:8501.

By default it runs in **demo mode** with placeholder answers. To use the real model, set `USE_MOCK = False` in
`assistant/config.py` (this also needs the real retrieval code and Ollama running, see that file).

## What is where

```
ui_backend/
├── ui/                          THE FRONT END (what people see)
│   ├── app.py                   Home page: the chat. Read this one first.
│   ├── pages/
│   │   ├── 1_Explain_a_document.py   Paste or upload text and get a plain-language explanation
│   │   └── 2_Analytics.py            Charts built from the question log
│   ├── theme.py                 Colours, light/dark mode, sidebar logo and links (used by all pages)
│   ├── styles/
│   │   ├── base.css             Styling shared by every page
│   │   └── chat.css             Styling for the chat page only
│   └── assets/                  Logo and browser-tab icon
│
├── assistant/                   THE BACK END (the thinking part, the UI never changes it)
│   ├── config.py                Settings: demo mode, model name, topics, sample questions, disclaimer
│   └── pipeline.py              ask() answers a question, explain_document() explains a document
│
├── data/logs/                   Question log used by Analytics (counts and timings only, never question text)
├── .streamlit/config.toml       Streamlit settings (base theme, upload size limit)
└── requirements.txt             Python packages
```

## How a question travels

1. You type a question on the Home page (`ui/app.py`).
2. `answer_question()` calls `ask(question, history, topic)` from `assistant/pipeline.py`. This is the only place the
   chat page talks to the back end.
3. `ask()` returns a dictionary: `answer`, `citations` (the sources), `grounded`, `warnings` and `urgent`.
4. `show_answer()` draws it: the text, any warnings, the sources and how long it took.

Streamlit runs a page file again from the top every time you click or type. Anything that has to survive
(the chats, the light/dark choice) is kept in `st.session_state`.

## Where do I change...?

| I want to change | Go to |
|---|---|
| A colour (works in light and dark) | `LIGHT_VARS` / `DARK_VARS` in `ui/theme.py` |
| Spacing, sizes or shapes on every page | `ui/styles/base.css` |
| Spacing, sizes or shapes on the chat page | `ui/styles/chat.css` |
| The welcome text or the suggestion cards' layout | section 7 of `ui/app.py` |
| The suggestion questions, topics or disclaimer | `assistant/config.py` |
| Demo mode on or off, the model name | `assistant/config.py` |
| The logo | `MARK_SVG` in `ui/theme.py`, and the files in `ui/assets/` |
| The links in the sidebar | `NAV` in `ui/theme.py` |

## Light and dark mode

The sidebar has an **Appearance** switch with three choices.

- **System** follows the phone or computer's setting.
- **Light** and **Dark** force one of them.

Every colour is a named value like `--bg` or `--ink`. The two colour lists in `ui/theme.py` give each name a light
and a dark value, and the CSS files only use the names. That is why one change in `theme.py` updates every page.
The choice is remembered while you move between pages (until the browser tab is refreshed).

## Adding another page

1. Add a file to `ui/pages/`, for example `3_My_page.py`.
2. Start it like the other two: call `st.set_page_config(...)`, then `theme.setup("mypage")` and `theme.back_to_home()`.
3. Add `("mypage", "pages/3_My_page.py", "My page")` to `NAV` in `ui/theme.py`.
