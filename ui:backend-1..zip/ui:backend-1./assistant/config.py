"""Central configuration. Change settings here, nowhere else."""
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

# True  -> fake retrieval + fake LLM (works with no other group's code)
# False -> real retriever (Group 1) + local LLM through Ollama (Group 2)
USE_MOCK = True

# Local LLM (Ollama runs on this machine, no external API)
OLLAMA_URL = "http://localhost:11434"
LLM_MODEL = "qwen3.5:4b"
REQUEST_TIMEOUT_S = 120

# Retrieval settings
TOP_K = 4
MIN_SIMILARITY = 0.2  # below this, answer "not covered" instead of guessing

# Analytics log (stores NO question text, only counts and timings)
LOG_PATH = ROOT / "data" / "logs" / "queries.jsonl"

DISCLAIMER = (
    "This is general legal information, not legal advice. "
    "For serious matters, speak to a qualified lawyer or a legal aid office."
)

# Label shown in the UI -> topic tag stored on chunks (None = no filter)
TOPICS = {
    "All topics": None,
    "Arrest and detention": "arrest-and-detention",
    "Fundamental rights": "fundamental-rights",
    "Housing and tenancy": "tenancy-housing",
    "Employment": "employment",
    "Consumer rights": "consumer",
}

SAMPLE_QUESTIONS = [
    "I was arrested. What are my rights?",
    "My landlord wants me out tomorrow. Is that allowed?",
    "My employer ended my job without notice. What can I do?",
]
